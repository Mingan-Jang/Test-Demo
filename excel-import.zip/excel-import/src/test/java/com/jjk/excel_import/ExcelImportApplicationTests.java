package com.jjk.excel_import;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExcelImportApplicationTests {

	@Test
	void contextLoads() {
	}

}
