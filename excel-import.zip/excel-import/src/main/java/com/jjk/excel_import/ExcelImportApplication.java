package com.jjk.excel_import;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcelImportApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcelImportApplication.class, args);
	}

}
